// وظائف Firebase
async function register(email, password) {
  try {
    const userCredential = await auth.createUserWithEmailAndPassword(
      email,
      password
    );
    // إضافة بيانات المستخدم إلى Firestore
    await db
      .collection("users")
      .doc(userCredential.user.uid)
      .set({
        email: email,
        activationCode: Math.floor(1000 + Math.random() * 9000),
        isActive: false
      });
    alert("تم إنشاء حسابك بنجاح! تحقق من بريدك الإلكتروني لتفعيل الحساب.");
  } catch (error) {
    console.error("خطأ في التسجيل: ", error.message);
  }
}

// وظيفة تسجيل الدخول
document
  .getElementById("loginForm")
  .addEventListener("submit", async function (event) {
    event.preventDefault();
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;

    try {
      const userCredential = await auth.signInWithEmailAndPassword(
        email,
        password
      );
      const userDoc = await db
        .collection("users")
        .doc(userCredential.user.uid)
        .get();

      if (userDoc.exists && userDoc.data().isActive) {
        alert("تم تسجيل الدخول بنجاح!");
        window.location.href = "categories.html";
      } else {
        alert("يرجى تفعيل حسابك أولاً. تحقق من بريدك الإلكتروني.");
      }
    } catch (error) {
      alert("البريد الإلكتروني أو كلمة المرور غير صحيحة.");
      console.error("خطأ في تسجيل الدخول: ", error.message);
    }
  });

// دالة للتبديل إلى صفحة التسجيل
function showRegister() {
  const email = prompt("أدخل بريدك الإلكتروني:");
  const password = prompt("أدخل كلمة المرور:");
  register(email, password);
}

// عرض المنتجات حسب القسم
function showProducts(category) {
  const products = [
    { id: 1, name: "قميص رجالي", price: 150, category: "رجالي" },
    { id: 2, name: "فستان نسائي", price: 250, category: "سيدات" },
    { id: 3, name: "لعبة أطفال", price: 80, category: "أطفال" }
  ];

  const filteredProducts = products.filter((p) => p.category === category);
  let productHtml = filteredProducts
    .map(
      (p) => `
        <div class="product">
            <h3>${p.name}</h3>
            <p>السعر: ${p.price} جنيه</p>
            <button onclick="addToCart(${p.id}, ${p.price})">أضف إلى السلة</button>
        </div>
    `
    )
    .join("");

  document.body.innerHTML =
    `<div class="header"><h1>منتجات ${category}</h1></div>` +
    productHtml +
    `<button onclick="goBack()">العودة للأقسام</button>`;
}

function goBack() {
  window.location.href = "categories.html";
}

// إضافة المنتجات إلى السلة
let cart = [];

function addToCart(id, price) {
  cart.push({ id, price });
  alert("تمت إضافة المنتج للسلة!");
}

// إتمام عملية الشراء مع الخصم
function checkout() {
  let total = cart.reduce((sum, item) => sum + item.price, 0);
  if (total > 500) {
    let discount = total * 0.02;
    total -= discount;
    alert(`تم تطبيق خصم 2٪. إجمالي الخصم: ${discount} جنيه`);
  }
  alert(`المجموع النهائي: ${total} جنيه`);
}
